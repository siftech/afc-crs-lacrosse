#!/bin/sh
h-to-ffi.sh /usr/include/gmp.h
